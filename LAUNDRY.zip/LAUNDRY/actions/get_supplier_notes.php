<?php
include_once("../includes/db_connect.php");
$supplier_id = intval($_GET["supplier_id"]);
$notes = mysqli_query($con, "SELECT * FROM supplier_notes WHERE supplier_id = $supplier_id ORDER BY created_at DESC");

if (mysqli_num_rows($notes) === 0) {
    echo "<p>No notes available for this supplier.</p>";
} else {
    echo "<ul class='list-group'>";
    while ($note = mysqli_fetch_assoc($notes)) {
        echo "<li class='list-group-item'>";
        echo "<strong>" . ucfirst($note['note_type']) . ":</strong> " . htmlspecialchars($note['note_content']);
        echo "<br><small class='text-muted'>By " . htmlspecialchars($note['created_by']) . " on " . $note['created_at'] . "</small>";
        echo "</li>";
    }
    echo "</ul>";
}
?>
