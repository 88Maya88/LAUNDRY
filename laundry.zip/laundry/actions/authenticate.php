<?php
// Enable errors for development (remove in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
header('Content-Type: application/json'); // Tell JS this is JSON

include_once("../includes/db_connect.php");

$status = 400;
$data = [];
$message = '';
$response = [];

// Safely read POST data
$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');
$role     = trim($_POST['role'] ?? '');

// Validate inputs
if ($username === '' || $password === '' || $role === '') {
    $message = "Please fill all fields.";
} else {
    // Prepare and execute user lookup
    $stmt = $con->prepare("SELECT * FROM users WHERE username = ? AND role = ?");
    $stmt->bind_param("ss", $username, $role);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_object();

        // Validate password (hashed or plain-text fallback)
        if (password_verify($password, $user->password) || $password === $user->password) {
            $_SESSION['user_username'] = $user->username;
            $_SESSION['users_id']  = $user->id;
            $_SESSION['user_role']     = $user->role;

            $status = 200;
            $message = "Success.";
            $data = $user;
        } else {
            $message = "Incorrect username or password.";
        }
    } else {
        $message = "Account does not exist or role mismatch.";
    }

    $stmt->close();
}

// Send JSON response
echo json_encode([
    'status'  => $status,
    'data'    => $data,
    'message' => $message
]);
exit();
