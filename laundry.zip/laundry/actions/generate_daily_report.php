<?php
session_start();
include_once("../includes/db_connect.php");

// Set headers for CSV download
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="daily_report.csv"');

$output = fopen("php://output", "w");

// Add headings to the CSV
fputcsv($output, ['Product ID', 'Name', 'Category', 'Stock', 'Status', 'Created By', 'Created At']);

// Get today's date (optional filter)
$date = $_GET['date'] ?? date('Y-m-d');

// Example: Fetch products created/updated today
$query = $con->prepare("
    SELECT product_id, product_name, category, current_stock, status, created_by, created_at
    FROM products
    WHERE DATE(updated_at) = ?
       OR DATE(created_at) = ?
    ORDER BY product_id ASC
");
$query->bind_param("ss", $date, $date);
$query->execute();
$result = $query->get_result();

// Output rows to CSV
while ($row = $result->fetch_assoc()) {
    fputcsv($output, $row);
}

fclose($output);
exit();
?>